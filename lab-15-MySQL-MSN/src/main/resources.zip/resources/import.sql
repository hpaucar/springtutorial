/* Populate tables */
INSERT INTO clientes (nombre, apellido, email, create_at) VALUES('Andres', 'Guzman', 'profesor@bolsadeideas.com', '2017-08-01');
INSERT INTO clientes (nombre, apellido, email, create_at) VALUES('John', 'Doe', 'john.doe@gmail.com', '2017-08-02');
